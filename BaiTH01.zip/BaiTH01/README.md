# BaiTH01 - Personal Portfolio

## Cấu trúc
- `index.html`: cấu trúc trang web
- `css/style.css`: giao diện, Flexbox/Grid, hover, responsive
- `js/script.js`: các tính năng tương tác

## Tính năng JavaScript
1. Menu hamburger trên mobile
2. Dark/Light mode + lưu trạng thái bằng localStorage
3. Smooth scroll
4. Hiển thị năm hiện tại tự động
5. Tìm kiếm dự án
6. Lọc dự án theo tag/category
7. Scroll reveal khi cuộn
8. Đếm ký tự tin nhắn
9. Validate form với nhiều điều kiện

## Responsive
- Tablet: `max-width: 900px`
- Mobile: `max-width: 640px`

## Chạy
Mở `index.html` bằng trình duyệt hoặc dùng Live Server trong VS Code.
