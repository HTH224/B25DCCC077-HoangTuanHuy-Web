// =========================
// 1. Hamburger menu
// =========================
const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");

menuToggle.addEventListener("click", () => {
    const isOpen = navMenu.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", isOpen);
});

document.querySelectorAll("#navMenu a").forEach((link) => {
    link.addEventListener("click", () => {
        navMenu.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
    });
});

// =========================
// 2. Dark / Light mode
// =========================
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");

function updateThemeIcon() {
    const isDark = document.body.classList.contains("dark");
    themeIcon.textContent = isDark ? "☾" : "☀";
    themeToggle.setAttribute(
        "aria-label",
        isDark ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối"
    );
}

if (localStorage.getItem("portfolio-theme") === "dark") {
    document.body.classList.add("dark");
}

updateThemeIcon();

themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");

    const currentTheme = document.body.classList.contains("dark")
        ? "dark"
        : "light";

    localStorage.setItem("portfolio-theme", currentTheme);
    updateThemeIcon();
});

// =========================
// 3. Smooth scroll
// =========================
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
        const targetId = anchor.getAttribute("href");
        const target = document.querySelector(targetId);

        if (target) {
            event.preventDefault();
            target.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }
    });
});

// =========================
// 4. Current year
// =========================
document.getElementById("currentYear").textContent = new Date().getFullYear();

// =========================
// 5. Project search + filter
// =========================
const searchInput = document.getElementById("projectSearch");
const filterButtons = document.querySelectorAll(".filter-btn");
const projectCards = document.querySelectorAll(".project-card");
const emptyState = document.getElementById("emptyState");

let currentFilter = "all";

function filterProjects() {
    const keyword = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    projectCards.forEach((card) => {
        const category = card.dataset.category;
        const tags = card.dataset.tags.toLowerCase();
        const text = card.textContent.toLowerCase();

        const matchesFilter =
            currentFilter === "all" || category === currentFilter;

        const matchesSearch =
            keyword === "" ||
            tags.includes(keyword) ||
            text.includes(keyword);

        const shouldShow = matchesFilter && matchesSearch;

        card.classList.toggle("is-hidden", !shouldShow);

        if (shouldShow) {
            visibleCount++;
        }
    });

    emptyState.hidden = visibleCount !== 0;
}

searchInput.addEventListener("input", filterProjects);

filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
        filterButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");

        currentFilter = button.dataset.filter;
        filterProjects();
    });
});

// =========================
// 6. Scroll reveal
// =========================
const revealElements = document.querySelectorAll(".reveal");

const revealObserver = new IntersectionObserver(
    (entries, observer) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("show");
                observer.unobserve(entry.target);
            }
        });
    },
    { threshold: 0.12 }
);

revealElements.forEach((element) => {
    revealObserver.observe(element);
});

// =========================
// 7. Character counter
// =========================
const messageInput = document.getElementById("message");
const charCount = document.getElementById("charCount");

messageInput.addEventListener("input", () => {
    charCount.textContent = `${messageInput.value.length}/300`;
});

// =========================
// 8. Form validation
// =========================
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

function setError(fieldId, errorId, message) {
    const field = document.getElementById(fieldId);
    const group = field.closest(".form-group");

    if (group) {
        group.classList.toggle("invalid", Boolean(message));
    }

    document.getElementById(errorId).textContent = message;
}

function validateForm() {
    let isValid = true;

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const subject = document.getElementById("subject").value.trim();
    const message = document.getElementById("message").value.trim();
    const agree = document.getElementById("agree").checked;

    // Name: required + minimum length
    if (!name) {
        setError("name", "nameError", "Vui lòng nhập họ tên.");
        isValid = false;
    } else if (name.length < 2) {
        setError("name", "nameError", "Họ tên phải có ít nhất 2 ký tự.");
        isValid = false;
    } else {
        setError("name", "nameError", "");
    }

    // Email: required + correct format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email) {
        setError("email", "emailError", "Vui lòng nhập email.");
        isValid = false;
    } else if (!emailRegex.test(email)) {
        setError("email", "emailError", "Email không đúng định dạng.");
        isValid = false;
    } else {
        setError("email", "emailError", "");
    }

    // Subject: required + minimum length
    if (!subject) {
        setError("subject", "subjectError", "Vui lòng nhập chủ đề.");
        isValid = false;
    } else if (subject.length < 3) {
        setError("subject", "subjectError", "Chủ đề phải có ít nhất 3 ký tự.");
        isValid = false;
    } else {
        setError("subject", "subjectError", "");
    }

    // Message: required + minimum length + maxlength
    if (!message) {
        setError("message", "messageError", "Vui lòng nhập tin nhắn.");
        isValid = false;
    } else if (message.length < 10) {
        setError("message", "messageError", "Tin nhắn phải có ít nhất 10 ký tự.");
        isValid = false;
    } else if (message.length > 300) {
        setError("message", "messageError", "Tin nhắn không được quá 300 ký tự.");
        isValid = false;
    } else {
        setError("message", "messageError", "");
    }

    // Checkbox: required
    document.getElementById("agreeError").textContent = agree
        ? ""
        : "Bạn cần tích đồng ý trước khi gửi.";

    if (!agree) {
        isValid = false;
    }

    return isValid;
}

contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    formStatus.textContent = "";
    formStatus.style.color = "";

    if (!validateForm()) {
        formStatus.textContent = "Vui lòng kiểm tra lại thông tin.";
        formStatus.style.color = "#df4e62";
        return;
    }

    formStatus.textContent =
        "Gửi thành công! Đây là form demo phía client.";
    formStatus.style.color = "#35a66a";

    contactForm.reset();
    charCount.textContent = "0/300";
});
